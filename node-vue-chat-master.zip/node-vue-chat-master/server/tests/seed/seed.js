const { populateData } = require('./seedFunctions');

populateData();
